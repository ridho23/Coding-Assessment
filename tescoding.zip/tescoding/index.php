<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Mengurutkan Nama Terakhir Yang sama</title>
</head>
<body>
<?php
	$fullname = array(
		"Orson Milka Iddins", "Erna Dorey Battelle", "Flori Chaunce Franzel", "Odetta Sue Kaspar", 
		"Roy Ketti Kopfen", "Madel Bordie Mapplebeck", "Selle Bellison", "Leonerd Adda Mitchell Monaghan", 
		"Debra Micheli", "Hailey Annakin", "Leonerd Adda Micheli Monaghan", "Avie Annakin"
	);

	$array = array();
	foreach($fullname as $name)
	{
		$parts = explode (" ", $name);
		
		echo 'Before sort : <br>';
		print_r($parts);
		
		echo '<br> After sort : <br>';
		$reverse = array_reverse($parts);
		$key = implode(" ", $reverse);
		echo $key;
		echo '<hr>';

		$array[$key] = $name;
	}
	ksort($array);
	print_r($array);

?>
</body>
</html>






<?php
//$fullname = array("d"=>"Orson Milka Iddins", "a"=>"Erna Dorey Battelle", "b"=>"Flori Chaunce Franzel", "c"=>"Odetta Sue Kaspar","d"=>"Roy Ketti Kopfen","e"=>"Madel Bordie Mapplebeck"
//,"f"=>"Selle Bellison","g"=>"Leonerd Adda Mitchell Monaghan","h"=>"Debra Micheli","i"=>"Hailey Annakin","j"=>"Leonerd Adda Micheli Monaghan","k"=>"Avie Annakin");

//$fullname = file($file);
//foreach ($fullname as $name)
//{
	//$parts = explode ("", $name);
	//$last = explode("", $parts[0]);
	//$last = end($last);
	//$array[$last] = $parts;
	
//}

//ksort($array);
//ksort($fruits);
//foreach ($fruits as $key => $val) {
//    echo "$key = $val\n";
?>